package za.ac.iie.asg1

import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        val btnRecommend = findViewById<Button>(R.id.btnRecommend)
        val btnClear = findViewById<Button>(R.id.btnClear)
        val rbBreakfast = findViewById<RadioButton>(R.id.rbBreakfast)
        val rbBrunch = findViewById<RadioButton>(R.id.rbBrunch)
        val rbLunch = findViewById<RadioButton>(R.id.rbLunch)
        val rbSnack = findViewById<RadioButton>(R.id.rbSnack)
        val rbDinner = findViewById<RadioButton>(R.id.rbDinner)
        val rbDessert = findViewById<RadioButton>(R.id.rbDessert)


        val RecommendText = findViewById<TextView>(R.id.txtResults)
        btnRecommend.setOnClickListener {
            if (rbBreakfast.isChecked) {
                RecommendText.text = "Avocado toast with poached eggs"
            } else if (rbBrunch.isChecked) {
                RecommendText.text = "Chicken and waffles"
            } else if (rbLunch.isChecked) {
                RecommendText.text = "Beef stew and rice"
            } else if (rbSnack.isChecked) {
                RecommendText.text = "Yoghurt bowl"
            } else if (rbDinner.isChecked) {
                RecommendText.text = "Pasta carbonara"
            } else if (rbDessert.isChecked) {
                RecommendText.text = "Chocolate lava cake"
            }
            else {
                RecommendText.text = "Please select a time of day a meal suggestion"
            }
        }
        btnClear.setOnClickListener {
            val group = findViewById<RadioGroup>(R.id.radioGroup)
            group.clearCheck()


            RecommendText.text = ""
        }












        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}